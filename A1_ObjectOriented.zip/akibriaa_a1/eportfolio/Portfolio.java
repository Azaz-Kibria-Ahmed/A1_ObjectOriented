package eportfolio;

import java.util.ArrayList;
import java.util.Arrays;

public class Portfolio {
	private ArrayList<Stock> stocks;
	private ArrayList<MutualFund> mfunds;
	private double netGains;

	public Portfolio() {
		this.stocks = new ArrayList<Stock>();
		this.mfunds = new ArrayList<MutualFund>();
		this.netGains = 0;
	}

	public ArrayList<Stock> getStocks() {
		return stocks;
	}

	public void setStocks(ArrayList<Stock> stocks) {
		this.stocks = stocks;
	}

	public ArrayList<MutualFund> getMFunds() {
		return mfunds;
	}

	public void setMufunds(ArrayList<MutualFund> mufunds) {
		this.mfunds = mufunds;
	}

	public double getNetGains() {
		return netGains;
	}

	public void setNetGains(double netGains) {
		this.netGains = netGains;
	}

	public boolean stockBought(String inSymbol) {
		for (Stock stock : stocks) {
			if (stock.getSymbol().equalsIgnoreCase(inSymbol))
				return true;
		}
		return false;
	}

	public boolean mFundBought(String inSymbol) {
		return mfunds.contains(new MutualFund(inSymbol, "", 0, 0));
	}

	public void updateBoughtStock(String inSymbol, double inPrice, int inQty) {
		for (Stock stock : stocks) {
			if (stock.getSymbol().equalsIgnoreCase(inSymbol)) {
				stock.setPrice(inPrice);
				stock.setQuantity(stock.getQuantity() + inQty);
				stock.setBookValue(stock.getBookValue() + inPrice * inQty + stock.getCommission());
			}
		}
	}

	public void addNewStock(String inSymbol, String inName, double inPrice, int inQty) {
		stocks.add(new Stock(inSymbol, inName, inPrice, inQty));

	}

	public void updateBoughtMFund(String inSymbol, double inPrice, int inQty) {
		int index = mfunds.indexOf(new MutualFund(inSymbol, "", inPrice, inQty));
		MutualFund mfund = mfunds.get(index);
		mfund.setPrice(inPrice);
		mfund.setQuantity(mfund.getQuantity() + inQty);
		mfund.setBookValue(mfund.getBookValue() + inPrice * inQty);
	}

	public void addNewMFund(String inSymbol, String inName, double inPrice, int inQty) {
		stocks.add(new Stock(inSymbol, inName, inPrice, inQty));

	}

	private ArrayList<Stock> searchStocksBySymbol(String inSymbol) {
		if (inSymbol.trim().isEmpty())
			return stocks;
		ArrayList<Stock> res = new ArrayList<Stock>();
		for (Stock stock : this.stocks) {
			if (stock.getSymbol().equalsIgnoreCase(inSymbol)) {
				res.add(stock);
				break;
			}
		}
		return res;

	}

	private ArrayList<MutualFund> searchMFundBySymbol(String inSymbol) {
		if (inSymbol.trim().isEmpty())
			return mfunds;

		ArrayList<MutualFund> res = new ArrayList<MutualFund>();
		for (MutualFund mfund : this.mfunds) {
			if (mfund.getSymbol().equalsIgnoreCase(inSymbol)) {
				res.add(mfund);
				break;
			}
		}
		return res;

	}

	private ArrayList<Stock> searchStockByKeywords(String keywords, ArrayList<Stock> stocks) {
		if (keywords.trim().isEmpty()) {
			return stocks;
		}

		ArrayList<Stock> res = new ArrayList<Stock>();
		ArrayList<String> splitKeywords = new ArrayList<String>();
		splitKeywords.addAll(Arrays.asList(keywords.split(" ")));
		for (Stock stock : stocks) {
			ArrayList<String> splitName = new ArrayList<String>();
			splitName.addAll(Arrays.asList(stock.getName().split(" ")));
			if (splitName.containsAll(splitKeywords)) {
				res.add(stock);
			}
		}

		return res;
	}

	private ArrayList<MutualFund> searchMFundByKeywords(String keywords, ArrayList<MutualFund> mfunds) {
		if (keywords.trim().isEmpty()) {
			return mfunds;
		}

		ArrayList<MutualFund> res = new ArrayList<MutualFund>();
		ArrayList<String> splitKeywords = new ArrayList<String>();
		splitKeywords.addAll(Arrays.asList(keywords.split(" ")));
		for (MutualFund mfund : mfunds) {
			ArrayList<String> splitName = new ArrayList<String>();
			splitName.addAll(Arrays.asList(mfund.getName().split(" ")));
			if (splitName.containsAll(splitKeywords)) {
				res.add(mfund);
			}
		}

		return res;
	}

	private ArrayList<Stock> searchStockByPriceRange(String range, ArrayList<Stock> stocks) {
		if (range.trim().isEmpty()) {
			return stocks;
		}

		ArrayList<Stock> res = new ArrayList<Stock>();
		double low = 0;
		double high = Double.MAX_VALUE - 8;

		if (range.contains("-")) {
			if (range.charAt(0) == '-') {
				high = Double.parseDouble(range.replace("-", ""));
			} else if (range.charAt(range.length() - 1) == '-') {
				low = Double.parseDouble(range.replace("-", ""));
			} else {
				low = Double.parseDouble(range.substring(0, range.indexOf('-')));
				high = Double.parseDouble(range.substring(range.indexOf('-') + 1));
			}
		} else {
			low = Double.parseDouble(range);
			high = low;
		}

		for (Stock stock : stocks) {
			if (low < stock.getPrice() && stock.getPrice() < high) {
				res.add(stock);
			}
		}
		return res;
	}

	private ArrayList<MutualFund> searchMFundByPriceRange(String range, ArrayList<MutualFund> mfunds) {
		if (range.trim().isEmpty()) {
			return mfunds;
		}

		ArrayList<MutualFund> res = new ArrayList<MutualFund>();
		double low = 0;
		double high = Double.MAX_VALUE - 8;

		if (range.contains("-")) {
			if (range.charAt(0) == '-') {
				high = Double.parseDouble(range.replace("-", ""));
			} else if (range.charAt(range.length() - 1) == '-') {
				low = Double.parseDouble(range.replace("-", ""));
			} else {
				low = Double.parseDouble(range.substring(0, range.indexOf('-')));
				high = Double.parseDouble(range.substring(range.indexOf('-') + 1));
			}
		} else {
			low = Double.parseDouble(range);
			high = low;
		}

		for (MutualFund mfund : mfunds) {
			if (low < mfund.getPrice() && mfund.getPrice() < high) {
				res.add(mfund);
			}
		}
		return res;
	}

	public void searchAllInvestments(String inSymbol, String keywords, String priceRange) {
		ArrayList<Stock> stockResults = searchStocksBySymbol(inSymbol);
		stockResults = searchStockByKeywords(keywords, stockResults);
		stockResults = searchStockByPriceRange(priceRange, stockResults);

		ArrayList<MutualFund> mFundResults = searchMFundBySymbol(inSymbol);
		mFundResults = searchMFundByKeywords(keywords, mFundResults);
		mFundResults = searchMFundByPriceRange(priceRange, mFundResults);

		for (Stock stock : stockResults) {
			System.out.println(stock.toString());
		}
		for (MutualFund mfund : mFundResults) {
			System.out.println(mfund.toString());
		}
	}


	public void sellStocks(String inSymbol, double inPrice, int inQty) {

		for (Stock stock : this.stocks) {
			if (stock.getSymbol().equalsIgnoreCase(inSymbol)) {
				if (stock.getQuantity() == inQty) {//full
					netGains = inPrice * inQty - stock.getCommission() - stock.getBookValue();
					this.stocks.remove(stock);
				} else if (stock.getQuantity() > inQty) {//partial
					double pay = inPrice * inQty - stock.getCommission();
					double sellBV = stock.getBookValue() * (stock.getQuantity()-inQty)/stock.getQuantity();
					this.netGains = pay - sellBV;
					stock.setBookValue(stock.getBookValue()-sellBV);
					stock.setQuantity(stock.getQuantity()-inQty);
				} else {
					System.out.printf("Not enough %s to sell", inSymbol);
				}
				return;
			}
		}

		System.out.printf("%s not found in owned stocks", inSymbol);

	}
	
	public void sellMFunds(String inSymbol, double inPrice, int inQty) {

		for (MutualFund mfund : this.mfunds) {
			if (mfund.getSymbol().equalsIgnoreCase(inSymbol)) {
				if (mfund.getQuantity() == inQty) {//full
					netGains = inPrice * inQty - mfund.getCommission() - mfund.getBookValue();
					this.mfunds.remove(mfund);
				} else if (mfund.getQuantity() > inQty) {//partial
					double pay = inPrice * inQty - mfund.getCommission();
					double sellBV = mfund.getBookValue() * (mfund.getQuantity()-inQty)/mfund.getQuantity();
					this.netGains = pay - sellBV;
					mfund.setBookValue(mfund.getBookValue()-sellBV);
					mfund.setQuantity(mfund.getQuantity()-inQty);
				} else {
					System.out.printf("Not enough %s to sell", inSymbol);
				}
				return;
			}
		}

		System.out.printf("%s not found in owned mutualfunds", inSymbol);

	}

}
