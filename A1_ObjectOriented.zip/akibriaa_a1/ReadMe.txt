Navigate to root directory containing the eportfolio directory

Compile using javac eportfolio/*.javac

Run using java eportfolio.A1

User input may not always be error checked.